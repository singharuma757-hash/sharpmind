import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const achievementDefsTable = pgTable("achievement_defs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  subject: text("subject"), // null = all subjects
});

export const playerAchievementsTable = pgTable("player_achievements", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAchievementDefSchema = createInsertSchema(achievementDefsTable).omit({ id: true });
export type InsertAchievementDef = z.infer<typeof insertAchievementDefSchema>;
export type AchievementDef = typeof achievementDefsTable.$inferSelect;
