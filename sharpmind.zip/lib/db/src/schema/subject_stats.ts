import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const subjectStatsTable = pgTable("subject_stats", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  subject: text("subject").notNull(), // math | physics | chemistry | logic
  tasksSolved: integer("tasks_solved").notNull().default(0),
  correctAnswers: integer("correct_answers").notNull().default(0),
  level: integer("level").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSubjectStatSchema = createInsertSchema(subjectStatsTable).omit({
  id: true,
  updatedAt: true,
});
export type InsertSubjectStat = z.infer<typeof insertSubjectStatSchema>;
export type SubjectStat = typeof subjectStatsTable.$inferSelect;
