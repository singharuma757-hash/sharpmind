import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const duelsTable = pgTable("duels", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  subject: text("subject").notNull(),
  difficulty: text("difficulty").notNull().default("medium"),
  status: text("status").notNull().default("pending"), // pending | active | completed
  player1Id: integer("player1_id"),
  player1Name: text("player1_name"),
  player1Score: integer("player1_score"),
  player2Id: integer("player2_id"),
  player2Name: text("player2_name"),
  player2Score: integer("player2_score"),
  winnerId: integer("winner_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const insertDuelSchema = createInsertSchema(duelsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertDuel = z.infer<typeof insertDuelSchema>;
export type Duel = typeof duelsTable.$inferSelect;
