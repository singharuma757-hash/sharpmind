import { pgTable, text, serial, integer, boolean, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const dailyQuestsTable = pgTable("daily_quests", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  goal: integer("goal").notNull().default(10),
  completed: integer("completed").notNull().default(0),
  xpReward: integer("xp_reward").notNull().default(50),
  questDate: date("quest_date", { mode: "string" }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertDailyQuestSchema = createInsertSchema(dailyQuestsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertDailyQuest = z.infer<typeof insertDailyQuestSchema>;
export type DailyQuest = typeof dailyQuestsTable.$inferSelect;
